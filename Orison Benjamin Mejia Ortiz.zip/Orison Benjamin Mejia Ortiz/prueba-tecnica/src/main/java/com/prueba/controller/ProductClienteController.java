package com.prueba.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.prueba.model.repository.GetProductClienteRepository;
import com.prueba.pojo.product.request.ProductRequest;
import com.prueba.process.GetProductProcess;

@RestController
@RequestMapping("/lifebank")
public class ProductClienteController {
	
	
	private GetProductClienteRepository productClienteRepo;
	@Autowired
	public ProductClienteController(GetProductClienteRepository productClienteRepo){
		this.productClienteRepo = productClienteRepo;
	}
	
	@GetMapping("/product")
	public ResponseEntity<?> productCliente(@RequestHeader("authorization") String authorization) {
		GetProductProcess productProcess = new GetProductProcess(productClienteRepo); 
		return productProcess.process(authorization);
	} 
}
